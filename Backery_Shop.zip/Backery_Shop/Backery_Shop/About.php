<?php
	include "header.php";
?>


<br />
<br />

<h2 align="center">About Us Bakery Shop</h2>
	<section class="w3ls-bnrbtm py-5" id="about">
		<div class="container py-xl-5 py-lg-3">
		
			<div class="row pb-5">
			
					
				<div class="col-lg-3">
				
					<img class="img-fluid" src="images/download (3).jpg" alt="">
				</div>
				<div class="col-lg-9 pl-lg-5 abou-right-w3layuts mt-lg-0 mt-5">
				<p>	We provide services for special occasions (such as weddings, birthday parties, anniversaries, or even business events) or for people who have allergies or sensitivities to certain foods (such as nuts, peanuts, dairy or gluten). We are providing a wide range of cakes designs such as fruit cakes, kids cakes, barbies cakes, and wedding cakes. Our bakery shop specialize in traditional or hand made types of bread made with locally milled flour, without flour bleaching agents or flour treatment agents, baking what is sometimes referred to as artisan bread.</p>
					
						
					
				</div>



	
		
</p>
</div>
</div>
</section>
<br />
<br />
<?php
	include "footer.php";
?>