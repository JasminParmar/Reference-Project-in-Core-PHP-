<?php 
session_start();
if(isset($_SESSION["ad_session"]))
{
		include("header.php");
		include("../conn.php");
		mysqli_query($con,"delete from feedback where fb_id=".$_REQUEST["id"]);
	
		echo "<script>window.location='FeedBackView.php';</script>";
}
	else	 

	echo "<script>window.location='Login.php';</script>";
?>	

<?php

		include("footer.php");
		
?>



