<?php /*?><!-- support -->
	<div class="support py-5" id="support">
		<div class="container py-xl-5 py-lg-3">
			<h3 class="title-w3ls text-center text-bl mb-5">Help & Support</h3>
			<div class="row support-bottom text-center mb-5">
				<div class="col-lg-4 support-grid">
					<span class="fa fa-headphones"></span>
					<h5 class="text-dark text-uppercase mt-4 mb-3">Online Support</h5>
					<p>Ut enim ad minima veniam, quis nostrum ullam corporis suscipit laboriosam.</p>
					<a href="../#" class="btn button-style-2 mt-sm-5 mt-4">
						Call Now
					</a>
				</div>
				<div class="col-lg-4 support-grid my-lg-0 my-5">
					<span class="fa fa-comments"></span>
					<h5 class="text-dark text-uppercase mt-4 mb-3">Live Chat 24/7</h5>
					<p>Ut enim ad minima veniam, quis nostrum ullam corporis suscipit laboriosam.</p>
					<a href="../#" class="btn button-style-2 mt-sm-5 mt-4">
						Let's Chat
					</a>
				</div>
				<div class="col-lg-4 support-grid">
					<span class="fa fa-question"></span>
					<h5 class="text-dark text-uppercase mt-4 mb-3">Any Questions</h5>
					<p>Ut enim ad minima veniam, quis nostrum ullam corporis suscipit laboriosam.</p>
					<a href="../#" class="btn button-style-2 mt-sm-5 mt-4">
						Learn More
					</a>
				</div>
			</div>
		</div>
	</div>
	<!-- support -->
<?php */?>
	<!-- copyright -->
	<div class="copy_right position-relative">
		<p class="text-center text-wh py-sm-3 py-3">� 2019 Baking. All rights reserved | Design by
			<a href="../http://w3layouts.com/" target="_blank">Namrata And Disha</a>
		</p>
		<!-- //move top icon -->
	</div>
	<!-- //copyright -->


</body>

</html>