<?php /*?><!-- support -->
	<div class="support py-5" id="support">
		<div class="container py-xl-5 py-lg-3">
			<h3 class="title-w3ls text-center text-bl mb-5">Help & Support</h3>
			<div class="row support-bottom text-center mb-5">
				<div class="col-lg-4 support-grid">
					<span class="fa fa-headphones"></span>
					<h5 class="text-dark text-uppercase mt-4 mb-3">Online Support</h5>
					<p>Ut enim ad minima veniam, quis nostrum ullam corporis suscipit laboriosam.</p>
					<a href="#" class="btn button-style-2 mt-sm-5 mt-4">
						Call Now
					</a>
				</div>
				<div class="col-lg-4 support-grid my-lg-0 my-5">
					<span class="fa fa-comments"></span>
					<h5 class="text-dark text-uppercase mt-4 mb-3">Live Chat 24/7</h5>
					<p>Ut enim ad minima veniam, quis nostrum ullam corporis suscipit laboriosam.</p>
					<a href="#" class="btn button-style-2 mt-sm-5 mt-4">
						Let's Chat
					</a>
				</div>
				<div class="col-lg-4 support-grid">
					<span class="fa fa-question"></span>
					<h5 class="text-dark text-uppercase mt-4 mb-3">Any Questions</h5>
					<p>Ut enim ad minima veniam, quis nostrum ullam corporis suscipit laboriosam.</p>
					<a href="#" class="btn button-style-2 mt-sm-5 mt-4">
						Learn More
					</a>
				</div>
			</div>
		</div>
	</div>
	<!-- support -->
	<?php */?>

	<!-- footer -->
	<footer>
		<div class="container">
			<?php /*?><!-- newsletter -->
			
			<div class="newsletter_right_w3w3pvt-lau p-lg-5 p-4" id="subscribe">
				<h3 class="title-w3ls-2 text-wh mb-5">Subscribe Newsletter</h3>
				<div class="n-right-w3ls">
					<form action="#" method="post">
						<div class="row">
							<div class="col-md-4 form-group">
								<input class="form-control" type="text" name="Name" placeholder="Name" required="">
							</div>
							<div class="col-md-4 form-group px-md-0">
								<input class="form-control" type="email" name="Email" placeholder="Email Address"
									required="">
							</div>
							<div class="col-md-4 form-group">
								<button class="submit btn" type="submit">Subscribe</button>
							</div>
						</div>
					</form>
				</div>
			</div>
			<!-- //newsletter -->
			<?php */?>
			
			<div class="py-5">
				<div class="row footer-grids pt-lg-3 pb-4">
					<div class="col-lg-4 footer-grid">
					
						<div class="footer-logo">
							<h2>
								<a class="logo mt-md-5 mt-1" href="index.php">Baking</a>
							</h2>
						</div>
					</div>
					<?php /*?><div class="col-lg-2 col-6 footer-grid mt-5">
						<h3 class="mb-sm-4 mb-3 pb-3">Home</h3>
						<ul class="list-unstyled">
							<li>
								<a href="index.php">Index</a>
							</li>
							<li>
								<a href="#about">About Us</a>
							</li>
							<li>
								<a href="#what">What We Do</a>
							</li>
							<li>
								<a href="#gallery">Gallery</a>
							</li>
							<li>
								<a href="#contact">Contact Us</a>
							</li>
						</ul>
					</div>
					<div class="col-lg-2 col-6 footer-grid mt-5">
						<h3 class="mb-sm-4 mb-3 pb-3"> Navigation </h3>
						<ul class="list-unstyled">
							<li>
								<a href="#what">Achievements</a>
							</li>
							<li>
								<a href="#services">Services</a>
							</li>
							<li>
								<a href="#testi">Reviews</a>
							</li>
							<li>
								<a href="#blog">Blog</a>
							</li>
						</ul>
					</div>
										<div class="col-lg-2 col-6 footer-grid mt-5">
						<h3 class="mb-sm-4 mb-3 pb-3"> Company</h3>
						<ul class="list-unstyled">
							<li>
								<a href="#">Link Here</a>
							</li>
							<li>
								<a href="#">Link Here</a>
							</li>
							<li>
								<a href="#">Link Here</a>
							</li>
						</ul>
					</div>
					<?php */?>
					<div class="col-lg-2 col-6 footer-grid mt-5">
						<h3 class="mb-sm-4 mb-3 pb-3">Contact Us</h3>
						<ul class="list-unstyled">
							<li>
								+91 9427494274
							</li>
							<li>
								<a href="mailto:info@example.com">backeryshop@gmail.com</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</footer>
	<!-- //footer -->
	<!-- copyright -->
	<div class="copy_right position-relative">
		<p class="text-center text-wh py-sm-3 py-3">� 2019 Baking. All rights reserved | Design by
			<a href="http://w3layouts.com/" target="_blank">Namrata and Disha</a>
		</p>
		<!-- move top icon -->
		<a href="#home" class="move-top text-center">
			<span class="fa fa-level-up" aria-hidden="true"></span>
		</a>
		<!-- //move top icon -->
	</div>
	<!-- //copyright -->


</body>

</html>