 <?php 
 session_start();
 if(isset($_SESSION["admin_user"]))
{
include('header1.php'); 
include "../connect.php";
 ?>

 <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>PRODUCT Details </h2>   
                    </div>
                </div>              
                 <!-- /. ROW  -->
                  <hr />
            <div class="row">
                    <div class="col-lg-6 col-md-6">      
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                Add Your Product here!...
                            </div>
                            <form method="post" enctype="multipart/form-data">
                            <div class="panel-body">         
                                <select name="category" class="form-control" required>
                                    <?php
                                    $sql1="select * from category";
                                    $all_categories=mysqli_query($conn,$sql1);
                                     while ($category = mysqli_fetch_array(
                                                $all_categories,MYSQLI_ASSOC)):;
                                                
                                    ?>
                                    
                                    <option value="<?php echo $category["cid"];?>">
                                      <?php echo $category["cname"];
                                        ?>
                                    </option>



                                    <?php
                                         endwhile;  
                                    ?>
                                </select>
                                <br>
                                <input type="text" name="p_name" class="form-control" placeholder="Product Name" />
                                <br>
                                <input type="text" name="p_price" class="form-control" placeholder="Price" />
                                <br>
                                <input type="text" name="p_desc" class="form-control" placeholder="Description" />
                                <br>
                                <input type="file" name="pro_img" class="form-control" placeholder="Select Image" />
                            </div>
                            <div class="panel-footer">
                                <input type="submit" name="submit" value="Submit" class="btn btn-primary"> 
                            </div> 
                            </form>                     
                        </div>
                    </div>
                 <!-- /. ROW  -->           
            </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
<?php

    if(isset($_POST['submit']))
    {
        

        $cat =$_POST['category'];
        $pnm =$_POST['p_name'];
        $price =$_POST['p_price'];
        $pdesc =$_POST['p_desc'];
              
        $path="upload/".$_FILES["pro_img"]["name"];
        move_uploaded_file($_FILES["pro_img"]["tmp_name"],"../".$path);

        $sql = "INSERT INTO product (cid,pname,pprice,pdesc,pimg) VALUES ('$cat','$pnm','$price','$pdesc','$path')";
        if (mysqli_query($conn, $sql)) 
        {
            echo "<script>alert('Your Product added successfully !');</script>";
        } 
        else 
        {
            echo "Error: " . $sql . "" . mysqli_error($conn);
        }
    }
?>
<?php include('footer1.php'); 
}
else
        echo "<script>window.location='login.php';</script>";
?>        