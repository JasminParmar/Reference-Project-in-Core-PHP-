<?php
session_start();
if(isset($_SESSION["admin_user"]))
{
include "../connect.php";

$query = "delete from category where cid='" . $_GET["userid"] . "'";

if (mysqli_query($conn, $query)) 
{
    echo "Record deleted successfully";
    header("Location: display_category.php");
} 
else 
{
    echo "Error deleting record: " . mysqli_error($conn);
}

}
else
        echo "<script>window.location='login.php';</script>";
?>  
