<?php  
session_start();
	include "../connect.php";

	if (isset($_POST["submit"])) 
	{
		$user=$_POST["unm"];
		$password=$_POST["pwd"];

		$qry=mysqli_query($conn, "select * from adminlogin where username='$user' and password='$password'");

		$row=mysqli_num_rows($qry);

		if ($row==1) 
		{
			echo "Login Successful";
			$_SESSION["admin_user"]=$user;

			header('location:index.php');
			exit();	
		}
		else
		{
			echo "<script>alert('Login Failed');</script>";
			//header('location:login.php');	
		}
	}
?>                           
<html>
<body>
	<form method="post">
	<table border="2" align="center">
		<tr>
			<th>Admin Login
		</tr>
		<tr>
			<td><input type="text" name="unm" placeholder="UserName"></td>
		</tr>
		<tr>
			<td><input type="password" name="pwd" placeholder="Password"></td>
		</tr>
		<tr>
			<td><input type="Submit" name="submit" value="Login"></td>
		</tr>		
	</form>
</body>
</html>