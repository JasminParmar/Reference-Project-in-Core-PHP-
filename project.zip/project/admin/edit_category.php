 <?php 
session_start();
if(isset($_SESSION["admin_user"]))
{
 include('header1.php');

    include "../connect.php";
    
	$qry = "select * from category where cid='" . $_GET["userid"] . "'";
	$records= mysqli_query($conn,$qry);
	$data = mysqli_fetch_array($records);
                                       
	
    if(isset($_POST['submit']))
    {
        $cname =$_POST['cat_name'];
      
        $sql = "update category set cname='$cname' where cid='" . $_GET["userid"] . "'";
        if (mysqli_query($conn, $sql)) 
        {
            //echo "<script>alert('Your Category UPDATED successfully !');</script>";
			header("Location: display_category.php");
        } 
        else 
        {
            echo "Error: " . $sql . "" . mysqli_error($conn);
        }       
    }
?>
 <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>CATEGORY Details </h2>   
                    </div>
                </div>              
                 <!-- /. ROW  -->
                  <hr />
            <div class="row">
                    <div class="col-lg-6 col-md-6">      
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                Update Your Category here!...
                            </div>
                            <form method="post">
                            <div class="panel-body">
                                <input type="text" value="<?php echo $data['cname']; ?>" name="cat_name" class="form-control" placeholder="Add Category" />
                            </div>
                            <div class="panel-footer">
                                <input type="submit" name="submit" value="Update" class="btn btn-primary"> 
                            </div> 
							
                            </form>                     
                        </div>
                    </div>
                 <!-- /. ROW  -->           
            </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>

<?php 
include('footer1.php'); 
}   
    else
        echo "<script>window.location='login.php';</script>";
?>      