 <?php 
session_start();
if(isset($_SESSION["admin_user"]))
{
 include('header1.php'); ?>

 <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Manage Products </h2>   
                    </div>
                </div>              
                 <!-- /. ROW  -->
                  <hr />
              <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <h5>Products here !....</h5>
                        <table class="table table-striped table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>PId</th>
                                    <th>Category Name</th>
                                    <th>Product Name</th>
                                    <th>Price</th>
                                    <th>Description</th>
                                    <th>Image</th>
                                    <th colspan="2">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php  
                                include "../connect.php";
                                    
                                $query = "select * from product";
                                $records= mysqli_query($conn,$query);
                                    while($data = mysqli_fetch_array($records))
                                        {
                                    ?>
                                      <tr>
                                        <td><?php echo $data['pid']; ?></td>
                                        <td><?php echo $data['cid']; ?></td>
                                        <td><?php echo $data['pname']; ?></td>
                                        <td><?php echo $data['pprice']; ?></td>
                                        <td><?php echo $data['pdesc']; ?></td>
                                           <?php echo "<td><img src='../".$data["pimg"]."' height=50px width=50px></td>"; ?>
                                        <td><a href="edit_product.php?userid=<?php echo $data["pid"]; ?>">Edit</a></td>
                                        <td><a href="delete_product.php?userid=<?php echo $data["pid"]; ?>">Delete</a></td>
                                      </tr> 
                                    <?php
                                        }
                                    ?>
                                  
                            </tbody>
                        </table>

                    </div>
                 <!-- /. ROW  -->           
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>

<?php 
include('footer1.php'); 
}   
    else
        echo "<script>window.location='login.php';</script>";
?>        