 <?php 
session_start();
if(isset($_SESSION["admin_user"]))
{
 include('header1.php'); 
?>

 <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Manage Category </h2>   
                    </div>
                </div>              
                 <!-- /. ROW  -->
                  <hr />
              <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <h5>Category's here !....</h5>
                        <table class="table table-striped table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>Category Id</th>
                                    <th>Category Name</th>
                                    <th colspan="2">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php  
                                include "../connect.php";
                                    
                                $query = "select * from category";
                                $records= mysqli_query($conn,$query);
                                    while($data = mysqli_fetch_array($records))
                                        {
                                    ?>
                                      <tr>
                                        <td><?php echo $data['cid']; ?></td>
                                        <td><?php echo $data['cname']; ?></td>
                                        
                                        <td><a href="edit_category.php?userid=<?php echo $data["cid"]; ?>">Edit</a></td>
                                        <td><a href="delete_category.php?userid=<?php echo $data["cid"]; ?>">Delete</a></td>
                                      </tr> 
                                    <?php
                                        }
                                    ?>
                                  
                            </tbody>
                        </table>

                    </div>
                 <!-- /. ROW  -->           
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>

<?php 
include('footer1.php'); 
}   
    else
        echo "<script>window.location='login.php';</script>";
?> 