 <?php include('header1.php'); ?>

 <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>CONTACT Details </h2>   
                    </div>
                </div>              
                 <!-- /. ROW  -->
                  <hr />
              <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <h5>User's FeedBack here !....</h5>
                        <table class="table table-striped table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Message</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php  
                                include "../connect.php";
                                $query = "select * from contact";
                                $records= mysqli_query($conn,$query);
                                    while($data = mysqli_fetch_array($records))
                                        {
                                    ?>
                                      <tr>
                                        <td><?php echo $data['id']; ?></td>
                                        <td><?php echo $data['name']; ?></td>
                                        <td><?php echo $data['email']; ?></td>
                                        <td><?php echo $data['phone']; ?></td>
                                        <td><?php echo $data['message']; ?></td>
                                        <td><a href="delete_contact.php?userid=<?php echo $data["id"]; ?>">Delete</a></td>
                                      </tr> 
                                    <?php
                                        }
                                    ?>
                            </tbody>
                        </table>

                    </div>
                 <!-- /. ROW  -->           
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>

<?php include('footer1.php'); ?>        